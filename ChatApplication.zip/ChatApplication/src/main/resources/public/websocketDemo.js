var flag = 0;
var pm = "";
// small helper function for selecting element by id
let id = id => document.getElementById(id);

//Establish the WebSocket connection and set up event handlers
let ws = new WebSocket("ws://" + location.hostname + ":" + location.port + "/chat");
ws.onmessage = msg => updateChat(msg);
ws.onclose = () => alert("WebSocket connection closed");

// Add event listeners to button and input field
id("submit").addEventListener("click", () => sendAndClearUser(id("uSername").value), id("password").value);
id("uSername").addEventListener("keypress", function (e) {
    if(e.keyCode === 13) {
        sendAndClearUser(e.target.value, id("password").value);
    }
});
id("password").addEventListener("keypress", function (e) {
    if(e.keyCode === 13) {
        sendAndClearUser(id("uSername").value, e.target.value);
    }
});

id("send").addEventListener("click", () => sendAndClear(id("message").value));
id("message").addEventListener("keypress", function (e) {
    if (e.keyCode === 13) { // Send message if enter is pressed in input field
        sendAndClear(e.target.value);
    }
});

id("submitREG").addEventListener("click", () => sendAndClearReg(id("usernameREG").value), id("passwordREG").value);
id("passwordREG").addEventListener("keypress", function (e) {
    if (e.keyCode === 13) {
        sendAndClearReg(id("usernameREG").value, e.target.value);
    }
});

function sendAndClearReg(username, password){
    if(username !== "" && password !== ""){
        String(username);
        String(password);
        username = "ID:REG" + username + "ID:PW" + password;
        ws.send(username);
        id("usernameREG").value = "";
        id("passwordREG").value = "";
    }
    if (username === null || password === null){
        console.log("Please enter both a username and password.");
        id("usernameREG").value = "";
        id("passwordREG").value = "";
    }
}

function sendAndClearUser(uSername, password) {
    if (uSername !== "" && password !== ""){
        String(uSername);
        String(password);
        uSername = "ID:LOGIN" + uSername + "ID:PW" + password;
        ws.send(uSername);
        id("uSername").value = "";
        id("password").value = "";
    }
    if (uSername === "" || password === ""){
        console.log("Please enter both a username and password.");
        id("uSername").value = "";
        id("password").value = "";
    }
}

function sendAndClear(message) {
    if (message !== "") {
        if(flag == 1){
            String(message);
            message = "ID:PM" + pm + "ID:MSG" + message;
            ws.send(message);
            id("message").value = "";
            flag = 0;
            pm = "";
        } else {
            ws.send(message);
            id("message").value = "";
        }
    }
}

function updateChat(msg) { // Update chat-panel and list of connected users
    let data = JSON.parse(msg.data);
    id("chat").insertAdjacentHTML("afterbegin", data.userMessage);
    id("userlist").innerHTML = data.userlist.map(user => "<li role=\"presentation\" class=\"link\" value=\"thing\" onclick=\"button('" + user + "')\"><span>" + user + "</span></li>").join("");
}

function button(newuser){;
    String(newuser);
    pm = newuser;
    flag = 1;
}